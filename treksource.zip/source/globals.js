const mapWidthQuadrants = 8;
const mapHeightQuadrants = 6;
const quadrantWidthSectors = 10;
const quadrantHeightSectors = 10;
const sectorDisplayWidthChars = 4;
const minKlingonsGame = 8;
